import {
  AINotConfiguredError,
  type AIGenerateOptions,
  type AICompletion,
  type AIMessage,
  type AIProvider,
  type AITool,
} from "@/ai/types";
import { getGeminiKey } from "@/ai/providers/keyStore";

const BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";

interface GeminiPart {
  text?: string;
  functionCall?: { id?: string; name?: string; args?: Record<string, unknown> };
  functionResponse?: { id?: string; name?: string; response?: unknown };
  /**
   * Opaque reasoning-state token. Lives on the Part itself, as a sibling of
   * functionCall/text — NOT nested inside functionCall. Wire field name is
   * camelCase (thoughtSignature), consistent with the surrounding fields.
   * Must be echoed back exactly as received.
   */
  thoughtSignature?: string;
}
interface GeminiCandidate {
  content?: { parts?: GeminiPart[] };
}
interface GeminiResponse {
  candidates?: GeminiCandidate[];
  error?: { message?: string };
}

function toContents(messages: AIMessage[]) {
  return messages
    .filter((message) => message.role !== "system")
    .map((message) => {
      // If this model turn came straight from Gemini, replay its exact
      // original Parts verbatim. This is the only way to guarantee
      // thoughtSignature (and any other Gemini-3 Part-level metadata, e.g.
      // a standalone "thought" part that isn't attached to the functionCall
      // part at all) survives — our generic AIToolCall shape can't model
      // every field Gemini's wire format carries, so reconstructing from it
      // is inherently lossy. Never decode, re-encode, reorder, or merge
      // these parts — pass them through unchanged.
      if (Array.isArray(message.providerRawParts) && message.providerRawParts.length) {
        return {
          role: message.role === "assistant" ? "model" : "user",
          parts: message.providerRawParts,
        };
      }

      const parts: Record<string, unknown>[] = [];

      // Text and tool calls are not mutually exclusive on a real Gemini turn
      // (a model turn can carry reasoning text alongside a functionCall) —
      // preserve both instead of dropping text whenever calls are present.
      if (message.content) {
        parts.push({ text: message.content });
      }

      if (message.toolCalls?.length) {
        for (const call of message.toolCalls) {
          const thoughtSignature = call.providerMetadata?.["thoughtSignature"];
          parts.push({
            functionCall: {
              name: call.name,
              args: call.args,
              // Only echo an id if Gemini actually issued one for this call.
              // Never fabricate one — an invented id is not what Gemini sent
              // and must not be replayed as though it were.
              ...(call.providerCallId ? { id: call.providerCallId } : {}),
            },
            ...(typeof thoughtSignature === "string" ? { thoughtSignature } : {}),
          });
        }
      } else if (message.toolResults?.length) {
        for (const result of message.toolResults) {
          parts.push({
            functionResponse: {
              name: result.name,
              response: { result: result.result },
              // Same rule as functionCall.id above: only present when the
              // originating call actually had a real provider id.
              ...(result.providerCallId ? { id: result.providerCallId } : {}),
            },
          });
        }
      }

      // Every content entry needs at least one part.
      if (parts.length === 0) parts.push({ text: "" });

      return {
        role: message.role === "assistant" ? "model" : "user",
        parts,
      };
    });
}

function extractText(payload: GeminiResponse): string {
  return (payload.candidates ?? [])
    .flatMap((candidate) => candidate.content?.parts ?? [])
    .map((part) => part.text ?? "")
    .join("");
}

function extractToolCalls(payload: GeminiResponse) {
  return (payload.candidates ?? []).flatMap((candidate) =>
    (candidate.content?.parts ?? []).flatMap((part, index) => {
      const call = part.functionCall;
      if (!call?.name) return [];
      return [
        {
          // Local bookkeeping ID only — used to correlate this call with its
          // AIToolResult inside this app. Never sent to Gemini.
          internalId: `${call.name}-${index}`,
          // Only set when Gemini actually returned an id (normally just for
          // parallel calls). Never fabricated — absence is preserved as
          // absence, not papered over with a synthetic value.
          ...(call.id ? { providerCallId: call.id } : {}),
          name: call.name,
          args: call.args ?? {},
          // thoughtSignature lives on the Part, alongside functionCall —
          // not inside it. Preserved opaquely and replayed as-is in
          // toContents(); never read or interpreted here.
          ...(part.thoughtSignature
            ? { providerMetadata: { thoughtSignature: part.thoughtSignature } }
            : {}),
        },
      ];
    }),
  );
}

function safeErrorMessage(message: string): string {
  const key = getGeminiKey();
  return key ? message.split(key).join("[redacted]") : message;
}

function containsSchemaKey(value: unknown, key: string): boolean {
  if (!value || typeof value !== "object") return false;
  if (Array.isArray(value)) return value.some((item) => containsSchemaKey(item, key));
  return Object.entries(value).some(
    ([entryKey, entryValue]) => entryKey === key || containsSchemaKey(entryValue, key),
  );
}

function assertGeminiToolSchemas(tools: AITool[]): void {
  if (tools.some((tool) => containsSchemaKey(tool.parameters, "additionalProperties"))) {
    throw new Error("Gemini tool schema contains unsupported additionalProperties.");
  }
}

/**
 * Direct browser -> Gemini implementation. No proxy, no backend, no key
 * leaving the device other than to Google.
 */
export function createGeminiProvider(model: string): AIProvider {
  function requireKey(): string {
    const key = getGeminiKey();
    if (!key) throw new AINotConfiguredError("Add your Gemini API key in Settings → AI / Gemini.");
    return key;
  }

  async function call(path: string, body: unknown, signal?: AbortSignal): Promise<Response> {
    return fetch(`${BASE_URL}/${model}:${path}`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": requireKey() },
      body: JSON.stringify(body),
      ...(signal ? { signal } : {}),
    });
  }

  function buildBody(messages: AIMessage[], options?: AIGenerateOptions) {
    const system = options?.system ?? messages.find((m) => m.role === "system")?.content;
    return {
      contents: toContents(messages),
      ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
      generationConfig: {
        ...(options?.temperature !== undefined ? { temperature: options.temperature } : {}),
        ...(options?.responseSchema
          ? { responseMimeType: "application/json", responseSchema: options.responseSchema }
          : {}),
      },
    };
  }

  function buildToolBody(messages: AIMessage[], tools: AITool[]) {
    assertGeminiToolSchemas(tools);
    const system = messages.find((m) => m.role === "system")?.content;
    return {
      contents: toContents(messages),
      ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
      tools: [
        {
          functionDeclarations: tools.map(({ name, description, parameters }) => ({
            name,
            description,
            parameters,
          })),
        },
      ],
    };
  }

  return {
    id: "gemini",
    label: "Google Gemini",
    async status() {
      const key = getGeminiKey();
      return {
        configured: Boolean(key),
        providerId: "gemini",
        model,
        ...(key ? {} : { message: "No API key configured." }),
      };
    },
    async testConnection() {
      try {
        const response = await call("generateContent", {
          contents: [{ role: "user", parts: [{ text: "Reply with OK." }] }],
        });
        const payload = (await response.json()) as GeminiResponse;
        if (!response.ok) {
          return {
            ok: false,
            message: `Connection failed for ${model} — ${safeErrorMessage(
              payload.error?.message ?? `HTTP ${response.status}`,
            )}`,
          };
        }
        return { ok: true, message: `Connected to ${model}.` };
      } catch (error) {
        return {
          ok: false,
          message: `Connection failed for ${model} — ${safeErrorMessage(
            error instanceof Error ? error.message : "Request failed.",
          )}`,
        };
      }
    },
    async generate(messages, options) {
      const response = await call("generateContent", buildBody(messages, options), options?.signal);
      const payload = (await response.json()) as GeminiResponse;
      if (!response.ok) {
        throw new Error(
          safeErrorMessage(payload.error?.message ?? `Gemini error ${response.status}`),
        );
      }
      return extractText(payload);
    },
    async generateWithTools(messages, tools): Promise<AICompletion> {
      const response = await call("generateContent", buildToolBody(messages, tools));
      const payload = (await response.json()) as GeminiResponse;
      if (!response.ok)
        throw new Error(
          safeErrorMessage(payload.error?.message ?? `Gemini error ${response.status}`),
        );
      const toolCalls = extractToolCalls(payload);
      return {
        text: extractText(payload),
        toolCalls,
        // Only needed (and only present) when this turn included a tool
        // call — plain text turns have nothing Gemini requires us to echo
        // back, and toContents() falls back to plain text reconstruction.
        ...(toolCalls.length
          ? { providerRawParts: payload.candidates?.[0]?.content?.parts ?? [] }
          : {}),
      };
    },
    async *stream(messages, options) {
      const response = await call(
        "streamGenerateContent?alt=sse",
        buildBody(messages, options),
        options?.signal,
      );
      if (!response.ok || !response.body) {
        const payload = (await response.json().catch(() => ({}))) as GeminiResponse;
        throw new Error(
          safeErrorMessage(payload.error?.message ?? `Gemini error ${response.status}`),
        );
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (!data || data === "[DONE]") continue;
          try {
            const delta = extractText(JSON.parse(data) as GeminiResponse);
            if (delta) yield { delta };
          } catch {
            // Ignore partial SSE frames.
          }
        }
      }
    },
  };
}
